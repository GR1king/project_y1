#include <stdio.h>
#include "gd32vf103.h"
#include "sht31.h"
#include "drivers.h"
#include "lcd.h"

static void delay_ms(int ms) {
    while (ms > 0) {
        while (!t5expq()) {
        }
        ms--;
    }
}

static void show_status(int temp_c) {
    /* Clear old status area */
    LCD_Fill(0, 50, 159, 79, BLACK);

    if (temp_c > temp_high) {
        LCD_ShowStr(0, 55, (u8 *)"WARNING: TEMP HIGH", RED, TRANSPARENT);
    } else if (temp_c < temp_low) {
        LCD_ShowStr(0, 55, (u8 *)"WARNING: TEMP LOW", BLUE, TRANSPARENT);
    } else {
        LCD_ShowStr(0, 55, (u8 *)"Temp normal", GREEN, TRANSPARENT);
    }

    LCD_Wait_On_Queue();
}

int main(void) {
    uint16_t temp_raw;
    uint16_t hum_raw;
    int temp_c;
    int hum_pct;
    int ret;
    char buf[40];

    /* Start timer */
    t5omsi();

    /* Start LCD */
    Lcd_SetType(LCD_INVERTED);
    Lcd_Init();
    LCD_Clear(BLACK);

    /* Start I2C for SHT31 */
    i2c_init_setup();

    /* Static text */
    LCD_ShowStr(0, 0,  (u8 *)"SHT31 Sensor", YELLOW, TRANSPARENT);
    LCD_ShowStr(0, 20, (u8 *)"Temp: ", WHITE, TRANSPARENT);
    LCD_ShowStr(0, 35, (u8 *)"Humidity: ", WHITE, TRANSPARENT);
    LCD_Wait_On_Queue();

    while (1) {
        ret = sht31_read((int16_t *)&temp_raw, &hum_raw);

        /* Clear old value areas */
        LCD_Fill(48, 20, 159, 31, BLACK);
        LCD_Fill(72, 35, 159, 46, BLACK);

        if (ret == 0) {
            sht31_convert((int16_t)temp_raw, hum_raw, &temp_c, &hum_pct);

            sprintf(buf, "%d C", temp_c);
            LCD_ShowStr(48, 20, (u8 *)buf, CYAN, TRANSPARENT);

            sprintf(buf, "%d %%", hum_pct);
            LCD_ShowStr(72, 35, (u8 *)buf, CYAN, TRANSPARENT);

            show_status(temp_c);
        } else {
            sprintf(buf, "Error: %d", ret);
            LCD_ShowStr(0, 55, (u8 *)buf, RED, TRANSPARENT);
        }

        LCD_Wait_On_Queue();
        delay_ms(1000);
    }
}