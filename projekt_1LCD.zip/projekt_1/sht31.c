#include "sht31.h"
#include "drivers.h"

#define SHT31_ADDR 0x44

static void wait_ms_sensor(int ms) {
    while (ms > 0) {
        while (!t5expq()) {
        }
        ms--;
    }
}

static uint8_t sht31_crc8(const uint8_t *data, int len) {
    uint8_t crc = 0xFF;
    int i, b;

    for (i = 0; i < len; i++) {
        crc ^= data[i];
        for (b = 0; b < 8; b++) {
            if (crc & 0x80) {
                crc = (uint8_t)((crc << 1) ^ 0x31);
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

void i2c_init_setup(void) {
    rcu_periph_clock_enable(RCU_I2C0);
    rcu_periph_clock_enable(RCU_GPIOB);
    rcu_periph_clock_enable(RCU_AF);

    gpio_init(GPIOB, GPIO_MODE_AF_OD, GPIO_OSPEED_50MHZ, GPIO_PIN_6 | GPIO_PIN_7);

    i2c_clock_config(I2C0, 100000, I2C_DTCY_2);
    i2c_enable(I2C0);
}

static void sht31_write_command(uint8_t cmd_msb, uint8_t cmd_lsb) {
    while (i2c_flag_get(I2C0, I2C_FLAG_I2CBSY));

    i2c_start_on_bus(I2C0);
    while (!i2c_flag_get(I2C0, I2C_FLAG_SBSEND));

    i2c_master_addressing(I2C0, SHT31_ADDR << 1, I2C_TRANSMITTER);
    while (!i2c_flag_get(I2C0, I2C_FLAG_ADDSEND));
    i2c_flag_clear(I2C0, I2C_FLAG_ADDSEND);

    i2c_data_transmit(I2C0, cmd_msb);
    while (!i2c_flag_get(I2C0, I2C_FLAG_TBE));

    i2c_data_transmit(I2C0, cmd_lsb);
    while (!i2c_flag_get(I2C0, I2C_FLAG_TBE));

    i2c_stop_on_bus(I2C0);
    while (I2C_CTL0(I2C0) & I2C_CTL0_STOP);
}

static void sht31_read_data(uint8_t size, uint8_t *data) {
    i2c_start_on_bus(I2C0);
    while (!i2c_flag_get(I2C0, I2C_FLAG_SBSEND));

    i2c_master_addressing(I2C0, SHT31_ADDR << 1, I2C_RECEIVER);
    while (!i2c_flag_get(I2C0, I2C_FLAG_ADDSEND));
    i2c_flag_clear(I2C0, I2C_FLAG_ADDSEND);

    i2c_ack_config(I2C0, I2C_ACK_ENABLE);

    for (int i = 0; i < size; i++) {
        if (i == size - 1) {
            i2c_ack_config(I2C0, I2C_ACK_DISABLE);
        }

        while (!i2c_flag_get(I2C0, I2C_FLAG_RBNE));
        *data++ = i2c_data_receive(I2C0);
    }

    i2c_stop_on_bus(I2C0);
    while (I2C_CTL0(I2C0) & I2C_CTL0_STOP);

    i2c_ack_config(I2C0, I2C_ACK_ENABLE);
}

int sht31_read(uint16_t *temp_raw, uint16_t *hum_raw) {
    uint8_t data[6];
    uint16_t t_raw;
    uint16_t h_raw;

    if ((temp_raw == 0) || (hum_raw == 0)) {
        return -1;
    }

    sht31_write_command(0x24, 0x00);
    wait_ms_sensor(20);
    sht31_read_data(6, data);

    if (sht31_crc8(&data[0], 2) != data[2]) {
        return -2;
    }

    if (sht31_crc8(&data[3], 2) != data[5]) {
        return -3;
    }

    t_raw = ((uint16_t)data[0] << 8) | data[1];
    h_raw = ((uint16_t)data[3] << 8) | data[4];

    *temp_raw = t_raw;
    *hum_raw = h_raw;

    return 0;
}

void sht31_convert(uint16_t temp_raw, uint16_t hum_raw, int *temp_c, int *hum_pct) {
    *temp_c = -45 + (int)((175L * temp_raw) / 65535L);
    *hum_pct = (int)((100L * hum_raw) / 65535L);

    if (*hum_pct < 0) *hum_pct = 0;
    if (*hum_pct > 100) *hum_pct = 100;
}