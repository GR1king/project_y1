build/main-2.o: main-2.S
