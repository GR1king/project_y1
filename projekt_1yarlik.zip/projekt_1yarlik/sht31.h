/* ========================= sht31.h ========================= */

#ifndef __SHT31_H
#define __SHT31_H

#include "gd32vf103.h"
#include <stdint.h>

/* Temperature limits for warning messages */
#define temp_high 28
#define temp_low  18

/* Function declarations */
void i2c_init_setup(void);
int sht31_read(int16_t *temp_raw, uint16_t *hum_raw);
void sht31_convert(int16_t temp_raw, uint16_t hum_raw, int *temp_c, int *hum_pct);

#endif