/* ========================= sht31.c ========================= */

#include "sht31.h"
#include "drivers.h"

/* I2C address of the sensor when ADDR pin is low */
#define SHT31_ADDR 0x44

/* Small wait function used inside sensor code */
static void wait_ms_sensor(int ms) {
    while (ms > 0) {
        while (!t5expq()) {
            /* wait until 1 ms passes */
        }
        ms--;
    }
}

/* CRC check function used by SHT31/SHT35
   This helps verify that the received data is correct */
static uint8_t sht31_crc8(const uint8_t *data, int len) {
    uint8_t crc = 0xFF;
    int i, b;

    for (i = 0; i < len; i++) {
        crc ^= data[i];
        for (b = 0; b < 8; b++) {
            if (crc & 0x80) {
                crc = (uint8_t)((crc << 1) ^ 0x31);
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

/* Set up I2C0 on PB6 = SCL and PB7 = SDA */
void i2c_init_setup(void) {
    rcu_periph_clock_enable(RCU_I2C0);   /* turn on clock for I2C0 */
    rcu_periph_clock_enable(RCU_GPIOB);  /* turn on clock for GPIOB */
    rcu_periph_clock_enable(RCU_AF);     /* turn on alternate-function clock */

    /* Configure PB6 and PB7 as alternate-function open-drain
       These are the typical I2C settings */
    gpio_init(GPIOB, GPIO_MODE_AF_OD, GPIO_OSPEED_50MHZ, GPIO_PIN_6 | GPIO_PIN_7);

    /* Set I2C speed to 100 kHz */
    i2c_clock_config(I2C0, 100000, I2C_DTCY_2);

    /* Enable I2C hardware */
    i2c_enable(I2C0);
}

/* Send a 2-byte command to the sensor
   For SHT31 measurement we use command 0x24 0x00 */
static void sht31_write_command(uint8_t cmd_msb, uint8_t cmd_lsb) {
    /* Wait until I2C bus is not busy */
    while (i2c_flag_get(I2C0, I2C_FLAG_I2CBSY));

    /* Send START condition */
    i2c_start_on_bus(I2C0);
    while (!i2c_flag_get(I2C0, I2C_FLAG_SBSEND));

    /* Send sensor address with WRITE mode */
    i2c_master_addressing(I2C0, SHT31_ADDR << 1, I2C_TRANSMITTER);
    while (!i2c_flag_get(I2C0, I2C_FLAG_ADDSEND));
    i2c_flag_clear(I2C0, I2C_FLAG_ADDSEND);

    /* Send first command byte */
    i2c_data_transmit(I2C0, cmd_msb);
    while (!i2c_flag_get(I2C0, I2C_FLAG_TBE));

    /* Send second command byte */
    i2c_data_transmit(I2C0, cmd_lsb);
    while (!i2c_flag_get(I2C0, I2C_FLAG_TBE));

    /* Send STOP condition */
    i2c_stop_on_bus(I2C0);
    while (I2C_CTL0(I2C0) & I2C_CTL0_STOP);
}

/* Read bytes from the sensor into a buffer */
static void sht31_read_data(uint8_t size, uint8_t *data) {
    /* Send START condition */
    i2c_start_on_bus(I2C0);
    while (!i2c_flag_get(I2C0, I2C_FLAG_SBSEND));

    /* Send sensor address with READ mode */
    i2c_master_addressing(I2C0, SHT31_ADDR << 1, I2C_RECEIVER);
    while (!i2c_flag_get(I2C0, I2C_FLAG_ADDSEND));
    i2c_flag_clear(I2C0, I2C_FLAG_ADDSEND);

    /* Enable ACK so MCU says "I received the byte, send next one" */
    i2c_ack_config(I2C0, I2C_ACK_ENABLE);

    /* Read requested number of bytes */
    for (int i = 0; i < size; i++) {
        if (i == size - 1) {
            /* For the last byte, do not ACK */
            i2c_ack_config(I2C0, I2C_ACK_DISABLE);
        }

        /* Wait until one byte has arrived */
        while (!i2c_flag_get(I2C0, I2C_FLAG_RBNE));

        /* Read the byte and store it in the buffer */
        *data++ = i2c_data_receive(I2C0);
    }

    /* Send STOP condition */
    i2c_stop_on_bus(I2C0);
    while (I2C_CTL0(I2C0) & I2C_CTL0_STOP);

    /* Turn ACK back on for next time */
    i2c_ack_config(I2C0, I2C_ACK_ENABLE);
}

/* Read one measurement from the SHT31 */
int sht31_read(int16_t *temp_raw, uint16_t *hum_raw) {
    uint8_t data[6];   /* sensor returns 6 bytes */
    uint16_t t_raw;
    uint16_t h_raw;

    /* Make sure the pointers are valid */
    if ((temp_raw == 0) || (hum_raw == 0)) {
        return -1;
    }

    /* Tell the sensor to start measuring
       0x24 0x00 = high repeatability, no clock stretching */
    sht31_write_command(0x24, 0x00);

    /* Wait for measurement to complete */
    wait_ms_sensor(20);

    /* Read 6 bytes:
       data[0] = temperature MSB
       data[1] = temperature LSB
       data[2] = temperature CRC
       data[3] = humidity MSB
       data[4] = humidity LSB
       data[5] = humidity CRC
    */
    sht31_read_data(6, data);

    /* Check CRC for temperature bytes */
    if (sht31_crc8(&data[0], 2) != data[2]) {
        return -2;
    }

    /* Check CRC for humidity bytes */
    if (sht31_crc8(&data[3], 2) != data[5]) {
        return -3;
    }

    /* Combine two 8-bit bytes into one 16-bit raw temperature value */
    t_raw = ((uint16_t)data[0] << 8) | data[1];

    /* Combine two 8-bit bytes into one 16-bit raw humidity value */
    h_raw = ((uint16_t)data[3] << 8) | data[4];

    /* Return raw results to caller */
    *temp_raw = (int16_t)t_raw;
    *hum_raw = h_raw;

    return 0;   /* success */
}

/* Convert raw sensor values into human-readable values */
void sht31_convert(int16_t temp_raw, uint16_t hum_raw, int *temp_c, int *hum_pct) {
    uint16_t t_u16 = (uint16_t)temp_raw;

    /* Formula from sensor datasheet:
       Temperature = -45 + 175 * raw / 65535
    */
    *temp_c = -45 + (int)((175L * t_u16) / 65535L);

    /* Formula from sensor datasheet:
       Humidity = 100 * raw / 65535
    */
    *hum_pct = (int)((100L * hum_raw) / 65535L);

    /* Make sure humidity stays between 0 and 100 */
    if (*hum_pct < 0) *hum_pct = 0;
    if (*hum_pct > 100) *hum_pct = 100;
}