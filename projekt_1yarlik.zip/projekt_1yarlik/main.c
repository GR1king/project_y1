/* ========================= main.c ========================= */

#include <stdio.h>
#include "gd32vf103.h"   /* MCU library */
#include "sht31.h"       /* our sensor functions */
#include "usart.h"       /* serial print functions */
#include "drivers.h"     /* timer functions */

/* Wait a number of milliseconds */
static void delay_ms(int ms) {
    while (ms > 0) {
        while (!t5expq()) {
            /* wait until Timer5 says 1 ms has passed */
        }
        ms--;
    }
}

/* Check if temperature is too high, too low, or normal */
static void check_temp(int temp_c) {
    if (temp_c > temp_high) {
        putstr("!! VARNING: Temp for HOG !!\r\n");
    } else if (temp_c < temp_low) {
        putstr("!! VARNING: Temp for LAG !!\r\n");
    } else {
        putstr(">> Temp normal\r\n");
    }
}

int main(void) {
    int16_t temp_raw;    /* raw temperature directly from sensor */
    uint16_t hum_raw;    /* raw humidity directly from sensor */
    int temp_c;          /* converted temperature in Celsius */
    int hum_pct;         /* converted humidity in % */
    int ret;             /* function return value (0 = OK, negative = error) */
    char buf[80];        /* text buffer for printing */

    u0init(1);           /* start USART0 so we can print text */
    t5omsi();            /* start Timer5 as 1 ms timer */
    i2c_init_setup();    /* set up I2C pins and I2C peripheral */

    putstr("SHT31 startar...\r\n");

    while (1) {
        /* Ask the sensor for one reading */
        ret = sht31_read(&temp_raw, &hum_raw);

        if (ret == 0) {
            /* Convert raw sensor values into real values */
            sht31_convert(temp_raw, hum_raw, &temp_c, &hum_pct);

            /* Build text like: Temp: 23 C, Luftfuktighet: 45 % */
            sprintf(buf, "Temp: %d C, Luftfuktighet: %d %%\r\n", temp_c, hum_pct);
            putstr(buf);

            /* Check if temperature is inside allowed range */
            check_temp(temp_c);
        } else {
            /* If sensor read failed, print the error code */
            sprintf(buf, "SHT31 felkod: %d\r\n", ret);
            putstr(buf);
        }

        /* Wait 1 second before next reading */
        delay_ms(1000);
    }
}