#include <stdio.h>
#include "gd32vf103.h"
#define LM75_ADDR 0x48 //mäter lufttemperaturen direkt runt sitt chip
//temp.c temperatur sensor test

void_